`timescale 1ns/1ps
module tb_engine;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;wire busy,done;
 wire [12:0] ra,wa,ow;wire [63:0] wd;wire we;wire [15:0] flags;
 reg [63:0] mem[0:4223],expected[0:4095];reg [63:0] q;
 integer cycles=0,k;
 stage_lab_engine #(.TARGET(4),.FIRST(4)) dut(.clk(clk),.rst(rst),.start(start),
 .input_stage(3'd3),.input_words(13'd4096),.read_addr(ra),.read_data(q),.write_en(we),.write_addr(wa),.write_data(wd),
 .busy(busy),.done(done),.output_words(ow),.flags(flags));
 always @(posedge clk)begin q<=mem[ra];if(we)mem[wa]<=wd;cycles<=cycles+1;end
 initial begin
  $readmemh("input.hex",mem,0,4095);$readmemh("expected.hex",expected);
  repeat(20)@(negedge clk);rst=0;start=1;@(negedge clk);start=0;
  while(!done && cycles<2000000)@(negedge clk);
  if(!done || ow!=4096 || flags[15:8]!=0)begin $display("FAIL timeout/flags count=%d flags=%h state=%d",ow,flags,dut.state);$finish;end
  repeat(3)@(negedge clk);
  for(k=0;k<4096;k=k+1)if(mem[k]!==expected[k])begin $display("FAIL output word=%d got=%h expected=%h",k,mem[k],expected[k]);$finish;end
  $display("PASS stage engine target=%d words=%d flags=%h cycles=%d",4,ow,flags,cycles);$finish;
 end
endmodule
