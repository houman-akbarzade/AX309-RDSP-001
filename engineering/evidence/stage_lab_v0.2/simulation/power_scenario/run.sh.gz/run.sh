source /opt/Xilinx/14.7/ISE_DS/settings64.sh
cd /home/houman/AX309-RDSP-001-stage-lab/rtl/build/stage_lab/sim/power_scenario
LD_PRELOAD=/home/houman/AX309-RDSP-001/rtl/build/redirect_gcc_exec.so fuse -mt off -L unisims_ver -L xilinxcorelib_ver -prj sim.prj -o tb work.tb_engine work.glbl > compile.log 2>&1
test -x tb || exit 1
./tb -tclbatch /home/houman/AX309-RDSP-001-stage-lab/rtl/tb/run_all.tcl > sim.log 2>&1
grep -q '^PASS stage engine' sim.log
