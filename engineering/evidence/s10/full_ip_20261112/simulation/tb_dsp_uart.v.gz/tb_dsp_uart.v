`timescale 1ns/1ps
module tb_dsp_uart;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,rxd=1;wire txd;
 wire [31:0] activations;
 uart_s05_dsp_top #(.CLOCK_HZ(1152000),.BAUD(115200),.TIMEOUT_CLKS(16000),.TX_ACK_TIMEOUT_CLKS(120000)) dut(
 .clk(clk),.rst(rst),.uart_rxd(rxd),.uart_txd(txd),.activation_count(activations));
 reg [7:0] inputs[0:47380],expected[0:72122];
 reg [79:0] actions[0:468];
 integer ai,k,b,n=0,cycles=0,before_wait;reg [7:0] value;
 always @(posedge clk)cycles=cycles+1;
 initial forever begin
  @(negedge txd);repeat(15)@(posedge clk);
  for(b=0;b<8;b=b+1)begin value[b]=txd;repeat(10)@(posedge clk);end
  if(txd!==1'b1 || n>72122 || value!==expected[n])begin
   $display("FAIL UART byte n=%d got=%h expected=%h action=%d corestate=%d",n,value,expected[n],ai,dut.u_core.state);$finish;
  end
  n=n+1;
 end
 task serial_byte;input [7:0] v;integer j;
 begin
  @(negedge clk);rxd=0;repeat(10)@(negedge clk);
  for(j=0;j<8;j=j+1)begin rxd=v[j];repeat(10)@(negedge clk);end
  rxd=1;repeat(10)@(negedge clk);
 end endtask
 initial begin
  $readmemh("input.hex",inputs);$readmemh("expected.hex",expected);$readmemh("actions.hex",actions);
  repeat(20)@(negedge clk);rst=0;repeat(20)@(negedge clk);
  for(ai=0;ai<=468;ai=ai+1)begin
   for(k=0;k<actions[ai][47:32];k=k+1)serial_byte(inputs[actions[ai][79:48]+k]);
   before_wait=cycles;
   while(n<actions[ai][31:0] && cycles-before_wait<2000000)@(negedge clk);
   if(n!=actions[ai][31:0])begin $display("FAIL timeout action=%d bytes=%d target=%d core=%d session=%d error=%b sat=%b",ai,n,actions[ai][31:0],dut.u_core.state,dut.u_session.state,dut.dsp_error,dut.dsp_sat);$finish;end
   repeat(100)@(negedge clk);
  end
  if(dut.cpi_open || activations!=1 || dut.tx_retry_exhausted)begin $display("FAIL final flags");$finish;end
  $display("PASS tb_dsp_uart: two full CPIs, independent exact IP/C05 output and power map, premature RUN, duplicate RUN, lost IQ/RESULT/COMMIT ACK, RELEASE and reuse; bytes=%d",n);$finish;
 end
 initial begin #1000000000;$display("FAIL global timeout");$finish;end
endmodule
