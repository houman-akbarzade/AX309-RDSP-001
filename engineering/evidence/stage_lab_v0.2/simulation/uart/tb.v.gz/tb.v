`timescale 1ns/1ps
module tb_uart;
 reg clk=0;always #10 clk=~clk;reg rst=1,rxd=1;wire txd;
 stage_lab_top #(.TARGET(4),.FIRST(4),.CLOCK_HZ(1152000),.BAUD(115200)) dut(.clk(clk),.rst(rst),.uart_rxd(rxd),.uart_txd(txd));
 reg [7:0] inputs[0:43026],expected[0:75626];reg [80:0] actions[0:217];
 integer n=0,ai,k,b,cycles=0,mark,starts=0;reg [7:0] value;
 always @(posedge clk)begin cycles=cycles+1;if(dut.run_engine)starts=starts+1;end
 initial forever begin
  @(negedge txd);repeat(15)@(posedge clk);
  for(b=0;b<8;b=b+1)begin value[b]=txd;repeat(10)@(posedge clk);end
  if(txd!==1 || n>75626 || value!==expected[n])begin $display("FAIL byte=%d got=%h expected=%h action=%d",n,value,expected[n],ai);$finish;end
  n=n+1;
 end
 task send_byte;input [7:0] v;integer j;
 begin @(negedge clk);rxd=0;repeat(10)@(negedge clk);
  for(j=0;j<8;j=j+1)begin rxd=v[j];repeat(10)@(negedge clk);end
  rxd=1;repeat(10)@(negedge clk);
 end endtask
 initial begin
  $readmemh("input.hex",inputs);$readmemh("expected.hex",expected);$readmemh("actions.hex",actions);
  repeat(20)@(negedge clk);rst=0;repeat(20)@(negedge clk);
  for(ai=0;ai<=217;ai=ai+1)begin
   for(k=0;k<actions[ai][48:33];k=k+1)send_byte(inputs[actions[ai][80:49]+k]);
   mark=cycles;
   while(n<actions[ai][32:1] && cycles-mark<200000)@(negedge clk);
   if(n!=actions[ai][32:1])begin $display("FAIL timeout action=%d state=%d",ai,dut.state);$finish;end
   if(actions[ai][0])while(!dut.complete)@(negedge clk);
   repeat(12000)@(negedge clk);
  end
  if(starts!=1)begin $display("FAIL duplicate RUN started %d times",starts);$finish;end
  $display("PASS Stage UART: CRC corruption, duplicate CONFIG/upload/read/RUN, premature RUN NACK, complete exact echo and 4096 Power words; bytes=%d",n);$finish;
 end
 initial begin #1000000000;$display("FAIL UART global timeout");$finish;end
endmodule
